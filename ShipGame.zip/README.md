SHIPGAME by Sergio Alvarez

It still needs the special features